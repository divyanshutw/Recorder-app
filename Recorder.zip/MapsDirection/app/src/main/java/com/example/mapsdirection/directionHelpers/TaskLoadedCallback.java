package com.example.mapsdirection.directionHelpers;

public interface TaskLoadedCallback {
    void onTaskDone(Object... values);
}